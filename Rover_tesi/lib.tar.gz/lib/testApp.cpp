/*
============================================================================
	Auth:			Daniele Palossi	(daniele.palossi@unibo.it)	
 	Description: 	Planner Library for SHERPA project					
============================================================================
*/


#include "planner.h"

int generate_reandom_obstacles(int nb_obstacles, int map_size_x, int map_size_y, int source_x, int source_y, int target_x, int target_y, std::list<int> &obstacles);


/* ---------------------------------- MAIN ---------------------------------- */
int main(int argc, char * argv[]) { 

	Planner p1;
	std::list<int> obstacles;
	srand(time(NULL));


	int map_size_x = 5;//(i+1)*10;//(rand() % MAX_MAP_SIZE)+1;
	int map_size_y = 5;//(i+1)*10;//(rand() % MAX_MAP_SIZE)+1;
	int source[] = {0, 0};//rand() % map_size_y; 
	int target[] = {map_size_x-1, map_size_y-1};//rand() % map_size_y;//map_size_y-1;//
	int nb_obstacles = 2;//map_size_x*map_size_y/2;//rand() % ((map_size_x*map_size_y)/2);
	std::list<int> path_cpu, path_gpu;

	generate_reandom_obstacles(nb_obstacles, map_size_x, map_size_y, source[0], source[1], target[0], target[1], obstacles);

	// int *a;
	// p1.update_map(a, 1);

	// p1.print_events();

	p1.set_map_size(map_size_x, map_size_y, 0);

	// p1.set_source(source[0], source[1], 0);

	// p1.set_destination(target[0], target[1], 0);

	// p1.set_obstacles(obstacles);

	// p1.print_automa(2);
	// p1.print_map_2D();

	// p1.set_destination(8, 7, 0);

	p1.set_map_size(20,20,0);

	p1.add_obstacle(4,4,0);
	p1.add_obstacle(4,1,0);

	p1.set_source(2, 2, 0);

	p1.set_destination(10, 10, 0);

	// p1.add_obstacle(1,1,0);

	// p1.add_obstacle(2,2,0);

	// p1.add_obstacle(3,3,0);

	// p1.add_obstacle(12,9,0);

	// p1.remove_obstacle(1,1,0);

	// p1.compute_CPU_path(path_cpu);

	p1.compute_GPU_path(0, path_gpu);

	// p1.print_automa(2);

	// p1.print_map_2D();

	// p1.print_map_path_2D(path_cpu);

	p1.print_map_path_2D(path_gpu);

	p1.set_destination(16, 16, 0);

	p1.add_obstacle(2,1,0);

	p1.add_obstacle(1,3,0);

	// p1.set_source(16, 16, 0);	

	// p1.compute_GPU_path(0, path_gpu);

	// p1.print_map_path_2D(path_gpu);

	// p1.compute_CPU_path(path_cpu);

	p1.compute_GPU_path(1, path_gpu);

	// p1.print_map_path_2D(path_cpu);

	p1.print_map_path_2D(path_gpu);

	// p1.print_path(path_gpu);

	// p1.test_path(path_cpu, path_gpu);

	p1.add_obstacle(2,1,0);

	p1.add_obstacle(13,7,0);

	p1.set_source(13, 6, 0);

	p1.compute_GPU_path(2, path_gpu);

	p1.print_map_path_2D(path_gpu);



	obstacles.clear();
	path_cpu.clear();
	path_gpu.clear();
}


int generate_reandom_obstacles(int nb_obstacles, int map_size_x, int map_size_y, int source_x, int source_y, int target_x, int target_y, std::list<int> &obstacles) {

	int nb_obstacles2 = 0;
	std::list<int>::iterator it;


	for(int i=0; i<nb_obstacles; i++) {

		int add_obst = true;
		int obstacle_x = (rand() % map_size_x);
		int obstacle_y = (rand() % map_size_y);

		if((obstacle_x != source_x || obstacle_y != source_y) && (obstacle_x != target_x || obstacle_y != target_y)) {


			for(it=obstacles.begin(); it!=obstacles.end(); ++it) {

   				int obst_x = *it;
    			it++;
    			int obst_y = *it;

    			if(obst_x==obstacle_x && obst_y==obstacle_y) {
    				add_obst = false;
    				break;
    			}
			}

			if(add_obst) {
				obstacles.push_back(obstacle_x);
				obstacles.push_back(obstacle_y);
				nb_obstacles2++;
			}

			add_obst = true;
		}
	}

	return nb_obstacles2;

}